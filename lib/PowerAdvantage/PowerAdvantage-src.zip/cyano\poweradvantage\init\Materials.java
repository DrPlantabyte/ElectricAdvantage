package cyano.poweradvantage.init;

import net.minecraft.block.material.*;

public class Materials {

	
	private static boolean initDone = false;
	public static void init(){
		if(initDone) return;
		
		
		initDone = true;
	}
}
